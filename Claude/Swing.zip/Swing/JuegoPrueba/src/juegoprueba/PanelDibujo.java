package juegoprueba;

import javax.swing.*;
import java.awt.*;


public class PanelDibujo extends JPanel
{
    int xE = Disparo.getxE();
    int yE = Disparo.getyE();
    private Jugador1 jugador1;
    private Jugador2 jugador2;
    
    public PanelDibujo()
    {
        this.jugador1 = new Jugador1();
        this.jugador2 = new Jugador2();
    }
    
    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        jugador2.dibujar(g);
        jugador1.dibujar(g);
        
        Enemigo.dibujar(g);
        Disparo.dibujar(g);
    }
    
    public void moverJugador1(int dx, int dy)
    {
        jugador1.setY((jugador1.getY() + dy));
        jugador1.setX((jugador1.getX() + dx));
        jugador1.isOut(Ventana.getAncho(), Ventana.getAlto());
        System.out.println(jugador1.getX());
        System.out.println(jugador1.getY());
        
        repaint();
    }
    
    public void moverJugador2(int dx, int dy)
    {
        jugador2.setY((jugador2.getY() + dy));
        jugador2.setX((jugador2.getX() + dx));
        jugador2.isOut(Ventana.getAncho(), Ventana.getAlto());
        System.out.println(jugador2.getX());
        System.out.println(jugador2.getY());
        
        repaint();
    }
    
    public void moverEnemigo(int dx, int dy)
    {
        
    }

}
