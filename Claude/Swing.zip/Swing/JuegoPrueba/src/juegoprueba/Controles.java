package juegoprueba;

import javax.swing.*;
import java.awt.event.*;

public class Controles implements KeyListener{
    
    private PanelDibujo sprite;
    int movimiento = 10;
    
    public Controles(PanelDibujo sprite)
    {
        this.sprite = sprite;
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
        System.out.println("Tecla presionada: " + e.getKeyChar());
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch(e.getKeyCode())
        {
            case KeyEvent.VK_W -> {
                sprite.moverJugador1(0, -movimiento);
            }
            case KeyEvent.VK_S -> {
                sprite.moverJugador1(0, movimiento);
            }
            case KeyEvent.VK_A -> {
                sprite.moverJugador1(-movimiento, 0);
            }
            case KeyEvent.VK_D -> {
                sprite.moverJugador1(movimiento, 0);
            }
            case KeyEvent.VK_UP -> {
                sprite.moverJugador2(0, -movimiento);
            }
            case KeyEvent.VK_DOWN -> {
                sprite.moverJugador2(0, movimiento);
            }
            case KeyEvent.VK_LEFT -> {
                sprite.moverJugador2(-movimiento, 0);
            }
            case KeyEvent.VK_RIGHT -> {
                sprite.moverJugador2(movimiento, 0);
            }
        }
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    
}
