package juegoprueba;

import java.awt.*;

public class Jugador1 extends Jugador
{
    private static int y = 100;
    private static int x = 100;
    private Color color = Color.BLUE;

    @Override
    public void dibujar(Graphics g) 
    {
        g.setColor(color);
        g.fillRect(x, y, 50, 50);
    }

    @Override
    public void isOut(int dx, int dy) {
        int x = getX();
        int y = getY();
        
        if(x >= dx)
        {
            setX(0);
        }
        
        if(x <= 0)
        {
            setX(Ventana.getAncho());
        }
        
        if(y >= dy)
        {
            setY(0);
        }
        
        if(y <= 0)
        {
            setY(Ventana.getAlto());
        }
    }

    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }

    public void setY(int y) {
        Jugador1.y = y;
    }

    public void setX(int x) {
        Jugador1.x = x;
    }
}
