package juegoprueba;

import java.awt.*;

public abstract class Jugador 
{    
    public abstract void dibujar (Graphics g);
    
    public abstract void isOut(int dx ,int dy);

}
