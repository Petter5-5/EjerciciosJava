
package ejercicio2_2_1;

public class Ejercicio2_2_1 
{
    public static void main(String[] args) 
    {
        float x = 144;
        float y = 999;
        System.out.println(x+y);
        System.out.println(x-y);
        System.out.println(x/y);    
        System.out.println(x*y);
    }
}
