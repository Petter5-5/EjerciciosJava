package ejercicio2_2_2;
public class Ejercicio2_2_2 
{
    public static void main(String[] args) 
    {
        String nombre = "Yeray Trejo Sanchez";
        System.out.println(nombre);
    }
}
