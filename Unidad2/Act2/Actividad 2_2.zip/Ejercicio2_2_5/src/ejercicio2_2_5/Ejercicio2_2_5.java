package ejercicio2_2_5;
public class Ejercicio2_2_5 
{
    public static void main(String[] args) 
    {
        int x = 10;
        System.out.println(x = x / 2);
        System.out.println(x = x + 1);
        System.out.println(x = x * 2);
        System.out.println(x = x / 2);
        System.out.println(x = x - 10);
        System.out.println(x = x + 5);
    }
}
