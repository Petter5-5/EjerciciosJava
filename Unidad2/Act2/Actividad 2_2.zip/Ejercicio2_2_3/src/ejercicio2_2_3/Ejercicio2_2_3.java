package ejercicio2_2_3;
public class Ejercicio2_2_3 
{
    public static void main(String[] args) 
    {
        String nombre = "Yeray Trejo Sanchez";
        String direccion = "Calle Rodahuevos, 69 - Guaro (Malaga) - Espana";
        String numero = "555 123456";
        System.out.printf("%s%n%s%n%s%n", nombre, direccion, numero);
    }
}
