package ejercicio2_2_12;
public class Ejercicio2_2_12 
{
    public static void main(String[] args) 
    {
        int nota1 = 5;
        int nota2 = 8;
        int nota3 = 9;
        System.out.printf("Nota 1: %d%nNota 2: %d%nNota 3: %d%n",nota1, nota2, nota3);
        double promedio = (double) (nota1 + nota2 + nota3)/3;
        System.out.printf("El promedio es: %.2f%n", promedio);
                
    }
}
