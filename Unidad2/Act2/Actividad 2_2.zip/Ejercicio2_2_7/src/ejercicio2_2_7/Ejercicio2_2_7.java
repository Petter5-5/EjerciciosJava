package ejercicio2_2_7;
public class Ejercicio2_2_7 
{
    public static void main(String[] args) 
    {
        double d1 = 10;
        double d2 = 20;
        System.out.println(d1 * 2 - 4);//1
        System.out.println((d1 - 4) * 2);//2
        System.out.println(((2 + d1) / 12) + d2 );//3
        System.out.println((d2 / d1) / 2);//4
        System.out.println(d2/(d1/2));//5
        System.out.println(d2 - d1/4);//6
        System.out.println((d2 - d1) / 4);//7
        System.out.println(d2/d1 * 2);//8
        System.out.println(d2/(d1*2));//9
        System.out.println(d2*2 - d1/4);//10
        System.out.println(d2 * (100 - d1));//11
        System.out.println((d2 * (50 + d1)) / 10);//12
    }
}
