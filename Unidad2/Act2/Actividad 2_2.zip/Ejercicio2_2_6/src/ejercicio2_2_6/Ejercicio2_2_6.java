package ejercicio2_2_6;
public class Ejercicio2_2_6 
{
    public static void main(String[] args) 
    {
        String texto = "La casa de";
        System.out.println(texto);
        System.out.println(texto = texto + " Juan es");
        System.out.println(texto = texto + " el numero");
        System.out.println(texto = texto + " 25.");
    }
}
