
package ejercicio2_1_4;

public class Ejercicio2_1_4 {

    public static void main(String[] args) {
        System.out.printf("%-10s %-10s %-10s %-10s %-10s%n", "Lunes", "Martes", "Mierc.", "Jueves", "Viernes");
        System.out.println("=====      ======     ======     ======     =======");
        System.out.printf("%-11s %-11s %-11s %-11s %-11s%n", "PROG", "PROG", "PROG", "PROG","SIN");
        System.out.printf("%-11s %-11s %-11s %-11s %-11s%n", "PROG", "PROG", "PROG", "PROG","SIN");
        System.out.printf("%-11s %-11s %-11s %-11s %-11s%n", "ED", "SIN", "SIN", "LM","BDATO");
        System.out.printf("%-11s %-11s %-11s %-11s %-11s%n", "FOL", "SIN", "SIN", "LM","BDATO");
        System.out.printf("%-11s %-11s %-11s %-11s %-11s%n", "FOL", "BDATO", "ED", "BDATO","ED");
        System.out.printf("%-11s %-11s %-11s %-11s %-11s%n", "FOL", "BDATO", "ED", "BDATO","ED");
        
    }
    
}
