
package ejercicio2_1_8;

public class Ejercicio2_1_8 {

    public static void main(String[] args) {
        System.out.println("*********");
        System.out.println(" *     *");
        System.out.println("  *   *");
        System.out.println("   * *");
        System.out.println("    *");
    }
    
}
