
package ejercicio2_1_5;

public class Ejercicio2_1_5 {

    public static void main(String[] args) {
        System.out.printf("\u001B[33m%-10s %-10s %-10s %-10s %-10s%n", "Lunes", "Martes", "Mierc.", "Jueves", "Viernes");
        System.out.println("\u001B[33m=====      ======     ======     ======     =======");
        System.out.printf("\u001B[32m%-11s\u001B[32m%-11s\u001B[32m%-11s\u001B[32m%-11s\u001B[31m%-10s%n", "PROG", "PROG", "PROG", "PROG","SIN");
        System.out.printf("\u001B[32m%-11s\u001B[32m%-11s\u001B[32m%-11s\u001B[32m%-11s\u001B[31m%-10s%n", "PROG", "PROG", "PROG", "PROG","SIN");
        System.out.printf("\u001B[36m%-11s\u001B[31m%-11s\u001B[31m%-11s\u001b[37m%-11s\u001B[35m%-10s%n", "ED", "SIN", "SIN", "LM","BDATO");
        System.out.printf("\u001B[33m%-11s\u001B[31m%-11s\u001B[31m%-11s\u001b[37m%-11s\u001B[35m%-10s%n", "FOL", "SIN", "SIN", "LM","BDATO");
        System.out.printf("\u001B[33m%-11s\u001B[35m%-11s\u001B[36m%-11s\u001b[35m%-11s\u001B[36m%-10s%n", "FOL", "BDATO", "ED", "BDATO","ED");
        System.out.printf("\u001B[33m%-11s\u001B[35m%-11s\u001B[36m%-11s\u001b[35m%-11s\u001B[36m%-10s%n", "FOL", "BDATO", "ED", "BDATO","ED");
        
    }
    
}
