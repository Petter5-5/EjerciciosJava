
package ejercicio2_1_7;

public class Ejercicio2_1_7 {

    public static void main(String[] args) {
        System.out.println("    *");
        System.out.println("   * *");
        System.out.println("  *   *");
        System.out.println(" *     *");
        System.out.println("*********");
    }
    
}
