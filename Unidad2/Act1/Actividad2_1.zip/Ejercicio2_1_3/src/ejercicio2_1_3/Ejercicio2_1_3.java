
package ejercicio2_1_3;

public class Ejercicio2_1_3 {

    public static void main(String[] args) {
        //1
        System.out.printf("%-10s %20s%n", "Epic","Epico");
        //2
        System.out.printf("%-10s %20s%n", "Play","Jugar");
        //3
        System.out.printf("%-10s %20s%n", "Piano","Piano");
        //4
        System.out.printf("%-10s %20s%n", "Ball","Pelota");
        //5
        System.out.printf("%-10s %20s%n", "Fan","Ventilador");
        //6
        System.out.printf("%-10s %20s%n", "Screen","Pantalla");
        //7
        System.out.printf("%-10s %20s%n", "Icecream","Helado");
        //8
        System.out.printf("%-10s %20s%n", "Helicopter","Helicoptero");
        //9
        System.out.printf("%-10s %20s%n", "Duck","Pato");
        //10
        System.out.printf("%-10s %20s%n", "Rabbit","Conejo");
    }
    
}
