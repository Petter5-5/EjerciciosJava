
package ejercicio2_1_1;

public class Ejercicio2_1_1 {

    public static void main(String[] args) {
        System.out.print("Nombre: Yeray Trejo Sanchez");
    }
    
}
