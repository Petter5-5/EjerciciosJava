
package ejercicio2_1_2;

public class Ejercicio2_1_2 {

    public static void main(String[] args) {
        System.out.println("Nombre: Yeray Trejo Sanchez");
        System.out.println("Direccion: Trinidad");
        System.out.println("Telefono: 654 23 43 54");
    }
    
}
