
package ejercicio2_1_9;


public class Ejercicio2_1_9 {

    public static void main(String[] args) {
         System.out.println("=============================");
         System.out.println("Boletin de notas - Juan Perez");
         System.out.println("=============================");
         System.out.println("Asignatura        Nota");
         System.out.println("----------------------");
         System.out.printf("%-17s %.2f%n", "Programacion", 8.5);
         System.out.printf("%-17s %.2f%n", "Base de Datos", 7.3);
         System.out.printf("%-17s %.2f%n", "Entornos", 9.0);
         System.out.println("----------------------");
         System.out.printf("%-17s %.2f%n", "Nota media", 8.3);
    }
    
}
